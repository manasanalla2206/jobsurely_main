import { Amplify } from "aws-amplify";

// Note: Google OAuth client IDs are configured in the Cognito User Pool IdP.
// This frontend only needs the Cognito domain + app client ID.
const redirectUrl = window.location.origin;
const redirectUrlWithSlash = `${redirectUrl}/`;

Amplify.configure({
  Auth: {
    Cognito: {
      userPoolId: "eu-north-1_GsCzzuDd4",
      userPoolClientId: "l8u902nvbum66igapdjjo01h6",
      loginWith: {
        oauth: {
          domain: "jobsurely-auth.auth.eu-north-1.amazoncognito.com",
          scopes: ["openid", "email", "profile"],
          redirectSignIn: [redirectUrl, redirectUrlWithSlash],
          redirectSignOut: [redirectUrl, redirectUrlWithSlash],
          responseType: "code"
        }
      }
    }
  }
});
